import cv2
import numpy as np
from google.colab.patches import cv2_imshow
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input, decode_predictions
from tensorflow.keras.preprocessing import image

def predict_bird_breed(image_path):
    # Load the image
    img = cv2.imread(image_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)  # Convert BGR to RGB

    # Resize image to match ResNet input size
    img = cv2.resize(img, (224, 224))

    # Convert image to array and preprocess it
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array = preprocess_input(img_array)

    # Load pre-trained ResNet50 model
    model = ResNet50(weights='imagenet')

    # Make predictions
    predictions = model.predict(img_array)
    breed_prediction = decode_predictions(predictions, top=1)[0][0]  # Get only the top prediction

    # Display breed prediction
    breed, confidence = breed_prediction[1], breed_prediction[2]
    print(f"Breed: {breed}, Confidence: {confidence}")

    # Display the image
    cv2_imshow(img)

# Replace 'birdiebird.jpg' with your new image file path
image_path = '/content/flamingo.jpg'
predict_bird_breed(image_path)